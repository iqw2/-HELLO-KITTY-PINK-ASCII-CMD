# -*- coding: utf-8 -*-
import os, sys, socket, ssl, json, time, hashlib, base64, urllib.parse, urllib.request, urllib.error, ipaddress, subprocess, platform
from datetime import datetime

P="\033[95m"; C="\033[96m"; W="\033[97m"; D="\033[90m"; R="\033[0m"
LOGO = r"""....................................................................................................
....................................................................................................
..........              =@%..                  .                                      .   ..........
..........              +@@%.                     .                                       ..........
..........    .     .   =@@@-              .         .     .                              ..........
..........       .      :@@@+                        ..    . .                            ..........
.......... .   .        .@@@%+*##:.          .                                            ..........
..........              .=@@@@@@@#.                              .                        ..........
..........           .  ..@@@@-:...     .                            ....                 ..........
..........           .  ..#@@@#+:..  ....:--....               ............  .   .        ..........
..........              ..+@@@@@+..  .:%@@@@@@#-...   .        ...-+*=:...............    ..........
..........    .    .    ..=@@@@@@....+@@*....*@@@*..............#@%**#%@-+@@@@@@@@*...    ..........
.......... .              :@@@@@@=..+@@-...  ..-%@@%@@@@@@@@@@@@#******#@@@#=::::%@#..    ..........
..........                :@@@@@@@..@@=.       ..-##*+=======*@#*********@=... ..=@@..   ...........
..........                .@@@@@@@=-@@-. .     .............-@#****%#%%#*%@......=@@:.   ...........
..........                .@@---=@@#@@..  .               ..%%***#%**#@@@@@%.....=@@:.    ..........
..........   .   .     .  .%@----@@@@%..                  .:%#***#%#%@#****#@@@%%%@@:...  ..........
..........                .+@+---+@@@@..     .         . ...*@#****#@%******%@%#***#@+..  ..........
..........                .:@#---=@@@@..  .              ....:*%%@@@%@#****#@%*##***%#.   ..........
..........                . %%---=%@@...      .           ...........:@@@@@@@**%***#@=..  ..........
..........      ...       ..#@-=@@@@-...                  ...............%%*###****@*... ...........
...........     ...       ..%@-=@@@%.                    .           ....:%%#***#%@=..    ..........
..........   ..=@@=...    .=@@@@@@@+:  .   .  .                    . ......:##%##@@+..    ..........
.............-@@@@@@=.......#@@@@@@:.     ...... .                   ... . ......*@@...   ..........
...........+@@%=-=+@@@#-.....:@@@@@..     ..%@@=     .   .              .      ..=@@:.    ..........
...........-%@%=----=*%@@@@%#*@@@@@#*     .+@@@#             .       ......  ..-+*@@+:..............
.............=@@@+--------+#%%@@@@@=....  ..%@*.     ............    .+@@%.    .:+@@##@@#...........
..........   ..:@@@@+---------#@@@@@:...   .....     ...-%@=......   :@@@@.   ...*@#................
...........    ...+@@@@%##*+==#@@@@@@=..             ..%+--+@....    .-@@-.  .+%%@@+..... ..........
..........      .....:+*%@@@@@@@@@@@@@:....          ..+@*+##.....     .  .....:@@%%@#..  ..........
..........           .....+@@%#@@@@@@@@%:.....  .    ............         ..=#+@@#....... ..........
..........              ..+@*..@@@@@@@@@@@-..    .   ............     .   ...*@@@*....    ..........
..........     .          -@@@@@@@@@@@%:@@@@#+.....  ....  .  ..     .....:#@@@::%#...    ..........
..........              ...@@=%@@@@@@@@%@..+%@@@%=-........ ..........-+%@@@*:........ .  ..........
..........              .:+@@@@%@@@@@@@@-.....-@@@@@@@@%*=--::-=+%@@@@@@%+....         .  ..........
..........           .:%@@@@+==#@@@@@@@-.....:@@*===+*%@@@@@@@@@@@@@@@@@%:....     .      ..........
..........           .@@@+=+%@@@@@@@@@+.  ..+@@+=====%*:=@+====+@#.....-@@@=....          ..........
..........           .@@@@@@@*-@@*-#@@:.  .=@@+=%*+*@@-..%*++==*@*.... ..:%@@-..          ..........
.......... .     .   ..+%%+...:@@==@@%@@%+*@@==+@:..:@%@@@#-=@+=@@:.....=@@#%@%....       ..........
..........           .........=@@-+@@...:*@@+===+%@@@+..%:..:@+==@@:..#@@+...-@@...       ..........
..........             .     .+@@-+@@=...@@+=====@+::%@%+@@%*+===+@@#@@-...  .:@@.        ..........
..........                   .+@@--#@@=.*@#=====#%..-@@...#%=======@@=...    ..*@=.  .    ..........
..........                   .*@#---*@@.%@*======#@@%=#%=*@*=======@@..........%@-.     . ..........
..........                  ..#@*---=@@#@@+========================*@%=+=....-@@+..       ..........
..........                   .@@*----@@@@@========#@%================#@@@@@@@@*:...    .  ..........
..........   .               .@@*----*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+....... .        ..........
..........             .  ...:@@+----=@@@:.......-@@=.................%@%..               ..........
..........                ...-@@=----=@@-..    ..@@*.                .#@@..               ..........
..........                ...*@@=----=@@:..   ..:@@.. .       .      .#@@..             . ..........
...........               ...#@@*#%@@@@@+........@@=.... .      .....-@@*..       .       ..........
..........                ...+@@@@%#=--@@@+......+@@-....      ....-%@@*...       . .     ..........
..........          .      ......... ...-%@@@@@@@@@@@@@@%%%%%%%%@@@@@*.....               ..........
..........       .                     .......::::---=*#%%@@@@%%#+-......                 ..........
..........                        .                  ..............                       ..........
.................................................................................................."""

def clear(): os.system("cls" if os.name=="nt" else "clear")
def ask(s): return input(f"{C}{s}{R} ").strip()
def pause(): input(f"\n{P}Enter drücken...{R}")
def get_json(url, timeout=8):
    req=urllib.request.Request(url, headers={"User-Agent":"PHANTOMS-EYE-Defensive-Toolkit/2.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r: return json.loads(r.read().decode("utf-8","replace"))
def normalize_url(raw):
    if "://" not in raw: raw="https://"+raw
    u=urllib.parse.urlparse(raw)
    if u.scheme not in ("http","https") or not u.hostname: raise ValueError("Nur gültige HTTP/HTTPS-URLs sind erlaubt.")
    return raw,u
def banner():
    clear()
    print(P+LOGO+R)
    print(P+" PHANTOMS EYE  |  ASCII PURPLE CMD"+R)
    print(C+" Defensive Cybersecurity Toolkit  •  "+datetime.now().strftime("%H:%M:%S")+R)
    print(P+"="*78+R)

def ip_deep():
    target=ask("TARGET IP / Hostname:")
    print(P+"\\n[IDENTIFICATION]"+R)
    try:
        try: ip=ipaddress.ip_address(target)
        except ValueError:
            infos=socket.getaddrinfo(target,None)
            ips=sorted({x[4][0] for x in infos})
            if not ips: raise ValueError("Keine IP aufgelöst.")
            print("Input Hostname:",target); print("Resolved IPs:",", ".join(ips))
            ip=ipaddress.ip_address(ips[0]); target=str(ip)
        else: print("Input IP:",ip)
        print("Primary IP Version:",f"IPv{ip.version}")
        print("Public / globally routable:",ip.is_global)
        print("Private:",ip.is_private); print("Reserved:",ip.is_reserved)
        try:
            name,aliases,addrs=socket.gethostbyaddr(str(ip))
            print(P+"\\n[DNS / RESOLUTION]"+R); print("PTR canonical name:",name)
            print("PTR aliases:",", ".join(aliases) or "none"); print("PTR addresses:",", ".join(addrs))
        except Exception as e: print("PTR: unavailable ("+str(e)+")")
        if ip.is_global:
            try:
                data=get_json("https://ipwho.is/"+urllib.parse.quote(str(ip)))
                print(P+"\\n[GEOLOCATION / NETWORK / ASN]"+R)
                for k in ("success","type","continent","continent_code","country","country_code","region","region_code","city","postal","latitude","longitude","is_eu","calling_code","capital","borders"):
                    if k in data: print(f"{k}: {data[k]}")
                for group in ("connection","timezone"):
                    val=data.get(group)
                    if isinstance(val,dict):
                        print(group.upper()+":")
                        for k,v in val.items(): print(f"  {k}: {v}")
                if data.get("flag"): print("FLAG:",data["flag"].get("emoji",""))
            except Exception as e: print("Geo/ASN API nicht erreichbar:",e)
            try:
                rdap=get_json("https://rdap.org/ip/"+urllib.parse.quote(str(ip)))
                print(P+"\\n[RDAP / REGISTRATION]"+R)
                print(json.dumps({k:rdap.get(k) for k in ("name","handle","startAddress","endAddress","ipVersion","type","country","status","parentHandle","port43") if k in rdap},indent=2,ensure_ascii=False))
                for ent in rdap.get("entities",[])[:8]:
                    vc=ent.get("vcardArray",[])
                    fn=""
                    if len(vc)>1:
                        for item in vc[1]:
                            if item and item[0]=="fn" and len(item)>3: fn=item[3]
                    print("Entity:",ent.get("handle",""),"Role:",",".join(ent.get("roles",[])), "Name:",fn)
            except Exception as e: print("RDAP nicht erreichbar:",e)
        print(D+"\\nHinweis: Geo-IP ist ungefähr; IP-Standorte sind nicht automatisch die Adresse einer Person."+R)
    except Exception as e: print("Fehler:",e)

def url_deep():
    raw=ask("TARGET URL / Domain:")
    try: url,u=normalize_url(raw)
    except Exception as e: print(e); return
    host=u.hostname
    print(P+"\\nTARGET: "+host+R); print("="*78)
    print(P+"[IDENTIFICATION]"+R); print("Input URL:",url); print("Hostname:",host); print("Scheme:",u.scheme); print("Port:",u.port or (443 if u.scheme=="https" else 80)); print("Path:",u.path or "/")
    try:
        ips=sorted({x[4][0] for x in socket.getaddrinfo(host,None)})
        print("Resolved IPs:",", ".join(ips))
        for x in ips:
            try: print("IP classification:",x,"global=",ipaddress.ip_address(x).is_global,"private=",ipaddress.ip_address(x).is_private)
            except ValueError: pass
    except Exception as e: print("DNS resolution failed:",e)
    try:
        name,aliases,addrs=socket.gethostbyname_ex(host)
        print(P+"\\n[DNS / RESOLUTION]"+R); print("Canonical name:",name); print("Aliases:",", ".join(aliases) or "none"); print("IPv4:",", ".join(addrs) or "none")
    except Exception as e: print("DNS details unavailable:",e)
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 PHANTOMS-EYE-Defensive-Toolkit/2.0"},method="GET")
        with urllib.request.urlopen(req,timeout=10) as r:
            print(P+"\\n[HTTP / RESPONSE]"+R); print("Status code:",r.status); print("Final URL:",r.geturl()); print("Redirected:",r.geturl()!=url)
            for h in ("Content-Type","Content-Length","Server","Last-Modified","Cache-Control","Location","ETag"): print(h+":",r.headers.get(h,"not disclosed"))
            headers=r.headers
    except urllib.error.HTTPError as e:
        print(P+"\\n[HTTP / RESPONSE]"+R); print("Status code:",e.code,e.reason); print("Final URL:",e.geturl()); headers=e.headers
    except Exception as e:
        print("HTTP request failed:",e); headers={}
    print(P+"\\n[SECURITY HEADERS]"+R)
    for h in ("Strict-Transport-Security","Content-Security-Policy","X-Content-Type-Options","X-Frame-Options","Referrer-Policy","Permissions-Policy","Cross-Origin-Opener-Policy","Cross-Origin-Resource-Policy"):
        print(h+":",headers.get(h,"NOT PRESENT"))
    if u.scheme=="https":
        print(P+"\\n[TLS]"+R)
        try:
            ctx=ssl.create_default_context()
            with socket.create_connection((host,u.port or 443),timeout=8) as sock:
                with ctx.wrap_socket(sock,server_hostname=host) as ss:
                    cert=ss.getpeercert()
                    print("TLS version:",ss.version()); print("Cipher:",ss.cipher()[0] if ss.cipher() else "unknown")
                    print("Certificate subject:",cert.get("subject","unknown")); print("Certificate issuer:",cert.get("issuer","unknown"))
                    print("Certificate expires:",cert.get("notAfter","unknown"))
        except Exception as e: print("TLS details unavailable:",e)
    print(D+"Note: missing headers alone do not prove a vulnerability. Geo-IP is approximate."+R)

def dns_tool():
    host=ask("Domain/Hostname:")
    try:
        for x in sorted({i[4][0] for i in socket.getaddrinfo(host,None)}): print(x)
        try: print("PTR:",socket.gethostbyaddr(host)[0])
        except Exception: pass
    except Exception as e: print("DNS error:",e)

def hash_tool():
    value=ask("Text oder lokaler Dateipfad:"); h=hashlib.sha256()
    if os.path.isfile(value):
        with open(value,"rb") as f:
            for chunk in iter(lambda:f.read(65536),b""): h.update(chunk)
    else: h.update(value.encode())
    print("SHA-256:",h.hexdigest())

def base64_tool():
    mode=ask("1=Codieren, 2=Decodieren:")
    value=ask("Text/Base64:")
    try: print(base64.b64encode(value.encode()).decode() if mode=="1" else base64.b64decode(value,validate=True).decode("utf-8","replace"))
    except Exception as e: print("Fehler:",e)

def json_tool():
    try: print(json.dumps(json.loads(ask("JSON einzeilig:")),indent=2,ensure_ascii=False))
    except Exception as e: print("JSON-Fehler:",e)

def headers_tool():
    raw=ask("URL:")
    try:
        url,u=normalize_url(raw); req=urllib.request.Request(url,headers={"User-Agent":"PHANTOMS-EYE/2.0"},method="HEAD")
        with urllib.request.urlopen(req,timeout=8) as r:
            print("Status:",r.status)
            for k,v in r.headers.items(): print(f"{k}: {v}")
    except Exception as e: print("Request failed:",e)

def email_headers():
    print("Füge E-Mail-Header ein. Leere Zeile beendet die Eingabe.")
    lines=[]
    while True:
        line=input()
        if not line: break
        lines.append(line)
    raw="\\n".join(lines)
    for key in ("From","Reply-To","Return-Path","Received","Authentication-Results","DKIM-Signature","Message-ID"):
        found=[line for line in raw.splitlines() if line.lower().startswith(key.lower()+":")]
        print(f"[{key}]")
        print("\\n".join(found[:8]) if found else "not found")
    print("Hinweis: Headertext allein bestätigt nicht, ob eine Mail echt oder sicher ist.")

def localhost_ports():
    print("Nur 127.0.0.1 (dein eigener Computer).")
    try:
        ports=sorted(set(int(x.strip()) for x in ask("Ports z.B. 80,443,8000:").split(",") if x.strip()))
        if any(p<1 or p>65535 for p in ports): raise ValueError
    except ValueError: print("Ungültige Portliste."); return
    for port in ports:
        s=socket.socket(); s.settimeout(.35)
        try: print(f"{port}: "+("OPEN" if s.connect_ex(("127.0.0.1",port))==0 else "closed/no response"))
        finally: s.close()

def ping_check():
    host=ask("Host (einzelner Ping):")
    cmd=["ping","-n","1",host] if os.name=="nt" else ["ping","-c","1",host]
    try: subprocess.run(cmd,timeout=5,check=False)
    except Exception as e: print("Ping failed:",e)

def system_info():
    print("OS:",platform.platform()); print("Python:",sys.version.split()[0]); print("Machine:",platform.machine()); print("Hostname:",socket.gethostname())

def log_analyzer():
    path=ask("Lokaler Logdateipfad:")
    if not os.path.isfile(path): print("Datei nicht gefunden."); return
    counts={"ERROR":0,"WARN":0,"INFO":0,"OTHER":0}
    with open(path,encoding="utf-8",errors="replace") as f:
        for line in f:
            up=line.upper(); key=next((k for k in ("ERROR","WARN","INFO") if k in up),"OTHER"); counts[key]+=1
    for k,v in counts.items(): print(f"{k}: {v}")

TOOLS=[
("01","IP Deep Lookup",ip_deep),("02","URL Deep Search",url_deep),("03","DNS Lookup",dns_tool),
("04","HTTP Security Headers",headers_tool),("05","SHA-256 Hash Analyzer",hash_tool),
("06","Base64 Analyzer",base64_tool),("07","JSON Inspector",json_tool),("08","Email Header Analyzer",email_headers),
("09","Localhost Port Check",localhost_ports),("10","Ping / Reachability",ping_check),
("11","Log File Analyzer",log_analyzer),("12","System Information",system_info)
]
def menu():
    while True:
        banner()
        print(C+"[ NETWORK / WEB ]"+R)
        print("  [01] IP Deep Lookup           [02] URL Deep Search")
        print("  [03] DNS Lookup               [04] HTTP Security Headers")
        print(C+"[ FILE / DATA ANALYSIS ]"+R)
        print("  [05] SHA-256 Hash Analyzer    [06] Base64 Analyzer")
        print("  [07] JSON Inspector           [08] Email Header Analyzer")
        print(C+"[ LOCAL / DIAGNOSTICS ]"+R)
        print("  [09] Localhost Port Check     [10] Ping / Reachability")
        print("  [11] Log File Analyzer        [12] System Information")
        print(P+"-"*78+R)
        print("[01-12] SELECT TOOL     [H] HELP     [Q] QUIT")
        choice=ask("phantoms-eye>")
        if choice.lower() in ("q","0","quit","exit"): break
        if choice.lower()=="h":
            print("Use only on systems/services you own or are authorized to assess.")
            print("Geo-IP can be approximate; absent HTTP headers are not proof of vulnerability."); pause(); continue
        tool=next((t for t in TOOLS if t[0]==choice.zfill(2)),None)
        if tool:
            clear()
            try: tool[2]()
            except KeyboardInterrupt: print("\\nCancelled.")
            except Exception as e: print("Tool error:",e)
            pause()
        else: print("Unknown selection."); time.sleep(.6)
    clear(); print(P+"PHANTOMS EYE closed."+R)

def intro():
    for _ in range(3):
        clear(); print(P+LOGO+R); time.sleep(1)
        clear(); time.sleep(1)
    menu()

if __name__=="__main__": intro()
