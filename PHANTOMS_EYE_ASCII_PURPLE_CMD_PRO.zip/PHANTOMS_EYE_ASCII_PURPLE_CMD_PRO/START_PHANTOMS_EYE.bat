@echo off
chcp 65001 >nul
title PHANTOMS EYE - ASCII PURPLE CMD
color 0D
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0phantoms_eye.py"
) else (
  python "%~dp0phantoms_eye.py"
)
if errorlevel 1 (
 echo.
 echo Python fehlt oder es gab einen Fehler.
 echo Python: https://www.python.org/downloads/
 pause
)
