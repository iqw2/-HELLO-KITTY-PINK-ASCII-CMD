PHANTOMS EYE — ASCII PURPLE CMD PRO

Start: ZIP entpacken, START_PHANTOMS_EYE.bat doppelklicken.
Python 3 erforderlich; keine Drittanbieter-Pakete erforderlich.
Das ASCII-Bild wird beim Start dreimal eingeblendet (je 1 Sekunde sichtbar,
je 1 Sekunde ausgeblendet). Danach bleibt es über dem Menü sichtbar.

Tools:
01 IP Deep Lookup (DNS/PTR, public/private classification, approximate geo/ASN, RDAP)
02 URL Deep Search (DNS, HTTP response/redirects, security headers, TLS certificate)
03 DNS Lookup
04 HTTP Security Headers
05 SHA-256 Hash Analyzer
06 Base64 Analyzer
07 JSON Inspector
08 Email Header Analyzer
09 Localhost Port Check (only 127.0.0.1)
10 Ping / Reachability
11 Log File Analyzer
12 System Information

Online lookup functions contact public services (ipwho.is and rdap.org) and the
entered website. Results can be incomplete or approximate. Missing security headers
alone do not prove a vulnerability. Use only on systems/services you own or are
authorized to assess.
